package exceptions;

public class KeyUndefinedException extends Exception {

	private static final long serialVersionUID = 1L;

	public KeyUndefinedException(String s){
		super(s);
	}
}
