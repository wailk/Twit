package exceptions;

public class Finish extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Finish(String s){
		super(s);
	}

}
